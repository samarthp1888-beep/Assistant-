package com.example.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AssistantService : AccessibilityService() {

    companion object {
        var instance: AssistantService? = null
        const val MODEL = "claude-sonnet-5-5" // change if you want another model
        const val MAX_STEPS = 20
    }

    @Volatile var stopped = false
    private var nodes = listOf<AccessibilityNodeInfo>()
    private val http = OkHttpClient.Builder().readTimeout(90, TimeUnit.SECONDS).build()

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }

    // ---------- Agent loop ----------
    fun run(goal: String, apiKey: String, log: (String) -> Unit) {
        stopped = false
        Thread {
            val history = mutableListOf<String>()
            try {
                for (step in 1..MAX_STEPS) {
                    if (stopped) { log("Stopped."); return@Thread }
                    val screen = readScreen()
                    val call = askClaude(goal, history, screen, apiKey)
                    val name = call.getString("name")
                    val input = call.getJSONObject("input")
                    if (name == "done") { log("✅ " + input.optString("message")); return@Thread }
                    log("$step. $name ${input.toString()}")
                    val result = execute(name, input)
                    history.add("$name $input -> $result")
                    Thread.sleep(1200)
                }
                log("Stopped: reached $MAX_STEPS steps.")
            } catch (e: Exception) {
                log("Error: ${e.message}")
            }
        }.start()
    }

    // ---------- Screen reading ----------
    private fun readScreen(): String {
        val root = rootInActiveWindow ?: return "(screen not readable)"
        val list = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo) {
            if (list.size >= 150) return
            val label = n.text ?: n.contentDescription
            if (n.isVisibleToUser && (n.isClickable || n.isEditable || n.isScrollable || !label.isNullOrBlank())) list.add(n)
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        nodes = list
        val lines = list.mapIndexed { i, n ->
            val flags = buildString {
                if (n.isClickable) append(" [clickable]")
                if (n.isEditable) append(" [editable]")
                if (n.isScrollable) append(" [scrollable]")
            }
            "[$i] ${n.className.toString().substringAfterLast('.')} \"${n.text ?: n.contentDescription ?: ""}\"$flags"
        }
        return "Current app: ${root.packageName}\n" + lines.joinToString("\n")
    }

    // ---------- Actions ----------
    private fun execute(name: String, input: JSONObject): String = when (name) {
        "tap" -> {
            val n = nodes.getOrNull(input.optInt("index", -1))
            if (n == null) "invalid index" else {
                var c: AccessibilityNodeInfo? = n
                while (c != null && !c.isClickable) c = c.parent
                if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) "ok" else {
                    val r = Rect(); n.getBoundsInScreen(r)
                    tapAt(r.exactCenterX(), r.exactCenterY()); "tapped by gesture"
                }
            }
        }
        "type_text" -> {
            val n = nodes.getOrNull(input.optInt("index", -1))
            if (n == null) "invalid index" else {
                n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, input.getString("text"))
                }
                if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "ok" else "failed"
            }
        }
        "scroll" -> {
            val s = nodes.firstOrNull { it.isScrollable }
            val act = if (input.optString("direction") == "up")
                AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            if (s != null && s.performAction(act)) "ok" else "nothing to scroll"
        }
        "open_app" -> {
            val q = input.getString("name").lowercase()
            val pm = packageManager
            val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val app = pm.queryIntentActivities(launcher, 0)
                .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            val intent = app?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
            if (intent == null) "app not found" else {
                startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "ok"
            }
        }
        "back" -> { performGlobalAction(GLOBAL_ACTION_BACK); "ok" }
        "home" -> { performGlobalAction(GLOBAL_ACTION_HOME); "ok" }
        "wait" -> { Thread.sleep(2000); "ok" }
        else -> "unknown action"
    }

    private fun tapAt(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
        dispatchGesture(g, null, null)
    }

    // ---------- Claude API ----------
    private fun p(type: String, desc: String) = JSONObject().put("type", type).put("description", desc)
    private fun tool(name: String, desc: String, props: JSONObject = JSONObject(), req: List<String> = emptyList()) =
        JSONObject().put("name", name).put("description", desc).put(
            "input_schema", JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(req))
        )

    private fun tools() = JSONArray().apply {
        put(tool("tap", "Tap a UI element by its index.", JSONObject().put("index", p("integer", "Element index")), listOf("index")))
        put(tool("type_text", "Type text into an editable element (replaces its text).",
            JSONObject().put("index", p("integer", "Element index")).put("text", p("string", "Text to type")), listOf("index", "text")))
        put(tool("scroll", "Scroll the main list.", JSONObject().put("direction", p("string", "up or down")), listOf("direction")))
        put(tool("open_app", "Launch an installed app by name.", JSONObject().put("name", p("string", "App name")), listOf("name")))
        put(tool("back", "Press the Back button."))
        put(tool("home", "Press the Home button."))
        put(tool("wait", "Wait 2 seconds for the screen to load."))
        put(tool("done", "Finish. Report the result, or explain why you stopped.",
            JSONObject().put("message", p("string", "Summary for the user")), listOf("message")))
    }

    private fun askClaude(goal: String, history: List<String>, screen: String, apiKey: String): JSONObject {
        val system = "You control an Android phone for the user by calling one tool per turn. " +
            "Complete the user's task step by step using the screen's numbered elements. " +
            "Call done when finished or stuck. Before anything irreversible or costly (payments, " +
            "purchases, deleting data, sending money), call done and ask the user to confirm instead of proceeding."
        val prompt = "Task: $goal\n\nActions so far:\n" +
            (if (history.isEmpty()) "(none)" else history.takeLast(15).joinToString("\n")) +
            "\n\nCurrent screen:\n$screen"
        val body = JSONObject()
            .put("model", MODEL).put("max_tokens", 1000).put("system", system)
            .put("tools", tools()).put("tool_choice", JSONObject().put("type", "any"))
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
        val req = Request.Builder().url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", apiKey).header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { res ->
            val text = res.body?.string() ?: ""
            if (!res.isSuccessful) throw Exception("API ${res.code}: ${text.take(200)}")
            val content = JSONObject(text).getJSONArray("content")
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                if (b.getString("type") == "tool_use") return b
            }
            throw Exception("No action returned")
        }
    }
}
