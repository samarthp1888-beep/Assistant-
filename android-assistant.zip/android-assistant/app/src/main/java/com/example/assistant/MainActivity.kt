package com.example.assistant

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var command: EditText
    private lateinit var logView: TextView

    private val voice = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { command.setText(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val key = EditText(this).apply {
            hint = "Anthropic API key (sk-ant-...)"
            setText(prefs.getString("key", ""))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        command = EditText(this).apply { hint = "What should I do?" }
        logView = TextView(this)

        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; setOnClickListener { onClick() }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad)
            addView(button("1. Enable accessibility service") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
            addView(key); addView(command)
            addView(button("🎤 Speak") {
                voice.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
            })
            addView(button("▶ Run") {
                val svc = AssistantService.instance
                if (svc == null) { toast("Enable the accessibility service first"); return@button }
                val k = key.text.toString().trim()
                if (k.isEmpty()) { toast("Enter your API key"); return@button }
                prefs.edit().putString("key", k).apply()
                logView.text = ""
                // Leave this app so the assistant can see and control other apps
                startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                svc.run(command.text.toString(), k) { line -> runOnUiThread { logView.append(line + "\n") } }
            })
            addView(button("■ Stop") { AssistantService.instance?.stopped = true })
            addView(logView)
        }
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
