# Android AI Assistant

1. In Android Studio: New Project > "Empty Views Activity", package `com.example.assistant`, min SDK 26.
2. Replace the generated files with the ones in this folder (AndroidManifest.xml, the two .kt files,
   res/xml/accessibility_config.xml, res/values/strings.xml) and merge the dependencies from app/build.gradle.kts.
3. Run on your phone (USB debugging on).
4. Open the app > "Enable accessibility service" > turn on "AI Assistant".
   (On Android 13+ sideloaded apps may need: App info > ⋮ > Allow restricted settings.)
5. Paste your Anthropic API key, type or speak a command, tap Run.

Notes: it stops after 20 steps, the Stop button halts it, and the model is told to ask before payments/deletions.
